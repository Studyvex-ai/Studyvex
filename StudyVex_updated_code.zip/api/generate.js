export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed." });
  }

  try {
    const body = req.body || {};
    const { text, task, count, bookTitle, chapter, pageFrom, pageTo, presentationTopic, slideCount } = body;

    const allowedTasks = [
      "summary", "mcq", "flashcards",
      "book_summary", "book_mcq", "book_flashcards",
      "presentation"
    ];

    if (!allowedTasks.includes(task)) {
      return res.status(400).json({ error: "Invalid task." });
    }

    if (!text || !text.trim()) {
      return res.status(400).json({ error: "Please provide source material." });
    }

    if (text.length > 20000) {
      return res.status(400).json({
        error: "Source material is too long. Please keep it under 20,000 characters."
      });
    }

    let instruction = "";

    if (task === "summary") {
      instruction =
        "Summarize the study material clearly for a university student. " +
        "Focus on important concepts, definitions, mechanisms, relationships, and exam-relevant points. " +
        "Use clear headings and bullet points.";
    }

    if (task === "mcq") {
      const questionCount = [10, 20, 30].includes(Number(count)) ? Number(count) : 10;
      instruction =
        `Create exactly ${questionCount} university-level multiple-choice questions from the study material. ` +
        "Each question must have four options labeled A, B, C, and D. " +
        "Include the correct answer and a short explanation after each question. " +
        "Test understanding and application, not only memorization.";
    }

    if (task === "flashcards") {
      instruction =
        "Create useful study flashcards from the material. " +
        "Format every card exactly as Question: followed by Answer:. " +
        "Focus on important concepts and definitions.";
    }

    if (task.startsWith("book_")) {
      const subtype = task.replace("book_", "");
      const bookContext =
        `Book title: ${bookTitle || "Not specified"}\n` +
        `Chapter/section: ${chapter || "Not specified"}\n` +
        `Requested pages: ${pageFrom || "Not specified"} to ${pageTo || "Not specified"}\n\n`;

      if (subtype === "summary") {
        instruction =
          bookContext +
          "Summarize ONLY the supplied source material for the requested book/chapter/page range. " +
          "Do not invent or claim access to pages that were not supplied. " +
          "Organize the summary clearly for studying.";
      } else if (subtype === "mcq") {
        instruction =
          bookContext +
          "Create 10 university-level MCQs ONLY from the supplied source material. " +
          "Use A-D options, give the correct answer and a short explanation. " +
          "Do not invent information not present in the supplied material.";
      } else {
        instruction =
          bookContext +
          "Create study flashcards ONLY from the supplied source material. " +
          "Format each card exactly as Question: and Answer:. " +
          "Do not invent information not present in the supplied material.";
      }
    }

    if (task === "presentation") {
      const slides = [6, 8, 10, 12, 15].includes(Number(slideCount))
        ? Number(slideCount)
        : 8;

      instruction =
        `Create a professional ${slides}-slide university presentation about "${presentationTopic || "the supplied topic"}". ` +
        "Base the content on the supplied source material. " +
        "For every slide provide: slide title, concise bullet points, speaker notes, and 1-2 suggested visual/image ideas. " +
        "Start with a title slide and finish with a concise conclusion/references slide where appropriate. " +
        "Do not invent specific sources or citations.";
    }

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-5.6-luna",
        input: `${instruction}\n\nSource material:\n${text}`
      })
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({
        error: data.error?.message || "OpenAI API request failed."
      });
    }

    return res.status(200).json({
      result: data.output_text || "No result was generated."
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      error: "Something went wrong while generating the result."
    });
  }
}
